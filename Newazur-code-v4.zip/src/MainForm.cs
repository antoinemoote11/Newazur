using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Windows.Forms;
using Windows.Globalization;
using Windows.Media.Ocr;
using Windows.Graphics.Imaging;
using Windows.Storage.Streams;

namespace AzurBot;

public sealed class MainForm : Form
{
    private readonly Button startButton = new() { Text = "DÉMARRER", Width = 145, Height = 44 };
    private readonly Button stopButton = new() { Text = "ARRÊTER", Width = 145, Height = 44, Enabled = false };
    private readonly Label status = new() { Text = "Prêt à démarrer", AutoSize = true };
    private readonly Label hpLabel = new() { Text = "PV joueur : --", AutoSize = true };
    private readonly Label thresholdLabel = new() { Text = "Retour au village sous 50 %", AutoSize = true };
    private readonly TrackBar thresholdTrackBar = new() { Minimum = 0, Maximum = 100, Value = 50, TickFrequency = 10, SmallChange = 1, LargeChange = 5, Width = 320 };
    private readonly ProgressBar hpProgress = new() { Minimum = 0, Maximum = 100, Value = 0, Width = 320, Height = 18 };
    private readonly System.Windows.Forms.Timer uiTimer = new() { Interval = 1000 };
    private volatile int returnThreshold = 50;
    private CancellationTokenSource? cts;
    private bool busy;
    private int lowHpReadings;
    private readonly object stateLock = new();

    public MainForm()
    {
        Text = "AzurBot";
        Width = 410;
        Height = 355;
        MinimumSize = new Size(410, 355);
        MaximumSize = new Size(410, 355);
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        BackColor = Color.FromArgb(17, 24, 39);
        ForeColor = Color.FromArgb(230, 240, 255);
        Font = new Font("Segoe UI", 9.5f);
        BuildInterface();
        FormClosing += (_, _) => StopBot();
    }

    private void BuildInterface()
    {
        var title = new Label
        {
            Text = "AZURBOT",
            Font = new Font("Segoe UI", 22, FontStyle.Bold),
            ForeColor = Color.FromArgb(56, 189, 248),
            AutoSize = true,
            Left = 24, Top = 16
        };
        var subtitle = new Label
        {
            Text = "Assistant de combat Windows",
            ForeColor = Color.FromArgb(156, 176, 199),
            AutoSize = true,
            Left = 27, Top = 56
        };

        startButton.Left = 25; startButton.Top = 91;
        stopButton.Left = 190; stopButton.Top = 91;
        StyleButton(startButton, Color.FromArgb(8, 145, 178));
        StyleButton(stopButton, Color.FromArgb(71, 85, 105));

        hpLabel.Left = 27; hpLabel.Top = 153;
        hpLabel.Font = new Font("Segoe UI", 11, FontStyle.Bold);
        hpProgress.Left = 27; hpProgress.Top = 178;
        thresholdLabel.Left = 27; thresholdLabel.Top = 216;
        thresholdTrackBar.Left = 22; thresholdTrackBar.Top = 237;
        thresholdTrackBar.Scroll += (_, _) =>
        {
            returnThreshold = thresholdTrackBar.Value;
            thresholdLabel.Text = $"Retour au village sous {returnThreshold} %";
        };
        status.Left = 27; status.Top = 296;
        status.ForeColor = Color.FromArgb(147, 197, 253);

        Controls.AddRange([title, subtitle, startButton, stopButton, hpLabel, hpProgress, thresholdLabel, thresholdTrackBar, status]);
        startButton.Click += (_, _) => StartBot();
        stopButton.Click += (_, _) => StopBot();
    }

    private static void StyleButton(Button button, Color color)
    {
        button.BackColor = color;
        button.ForeColor = Color.White;
        button.FlatStyle = FlatStyle.Flat;
        button.FlatAppearance.BorderSize = 0;
        button.Font = new Font("Segoe UI", 10, FontStyle.Bold);
        button.Cursor = Cursors.Hand;
    }

    private void StartBot()
    {
        if (busy) return;
        busy = true;
        lowHpReadings = 0;
        cts = new CancellationTokenSource();
        startButton.Enabled = false;
        stopButton.Enabled = true;
        SetStatus("Démarré : place le jeu au premier plan.");
        var token = cts.Token;
        _ = Task.Run(() => LoopAsync(token));
    }

    private void StopBot()
    {
        cts?.Cancel();
        cts?.Dispose();
        cts = null;
        busy = false;
        if (IsDisposed) return;
        startButton.Enabled = true;
        stopButton.Enabled = false;
        SetStatus("Arrêté");
    }

    private void SetStatus(string text)
    {
        if (IsDisposed || !IsHandleCreated) return;
        try { BeginInvoke(() => status.Text = text); } catch (InvalidOperationException) { }
    }

    private void SetHp(double? hp)
    {
        if (IsDisposed || !IsHandleCreated) return;
        try
        {
            BeginInvoke(() =>
            {
                hpLabel.Text = hp.HasValue ? $"PV joueur : {hp.Value:0} %" : "PV joueur : non lus";
                hpProgress.Value = hp.HasValue ? Math.Clamp((int)Math.Round(hp.Value), 0, 100) : 0;
                hpProgress.ForeColor = hp.HasValue && hp.Value <= returnThreshold ? Color.OrangeRed : Color.LimeGreen;
            });
        }
        catch (InvalidOperationException) { }
    }

    private async Task LoopAsync(CancellationToken token)
    {
        while (!token.IsCancellationRequested)
        {
            try
            {
                using var bmp = CaptureVirtualScreen();
                var hp = await DetectHpPercentAsync(bmp);
                SetHp(hp);

                if (hp.HasValue && hp.Value < returnThreshold) lowHpReadings++;
                else lowHpReadings = 0;

                var text = await ReadFrenchTextAsync(bmp);

                // Popup héros : mettre un point en Force puis confirmer.
                if (Contains(text, "CONFIRMER") && Contains(text, "Force"))
                {
                    SetStatus("Niveau du héros : + Force");
                    await Task.Delay(1500, token);
                    using var fresh = CaptureVirtualScreen();
                    if (await ClickForcePlusAsync(fresh, token))
                    {
                        await Task.Delay(900, token);
                        using var fresh2 = CaptureVirtualScreen();
                        var text2 = await ReadFrenchTextAsync(fresh2);
                        if (Contains(text2, "CONFIRMER"))
                        {
                            SetStatus("Force ajoutée : confirmation");
                            await ClickTextAsync(fresh2, "CONFIRMER", token);
                        }
                        else SetStatus("Confirmation non détectée");
                    }
                    else SetStatus("Bouton + Force introuvable");
                }
                else if (Contains(text, "COMPRIS"))
                {
                    SetStatus("Météo : Compris !");
                    await ClickTextAsync(bmp, "COMPRIS", token);
                }
                else if (Contains(text, "SUPER"))
                {
                    SetStatus("Compagnon : Super !");
                    await ClickTextAsync(bmp, "SUPER", token);
                }
                else if (Contains(text, "RENTRER AU VILLAGE") &&
                         hp.HasValue && hp.Value < returnThreshold && lowHpReadings >= 3)
                {
                    SetStatus($"PV sous {returnThreshold} % : retour au village");
                    await ClickTextAsync(bmp, "RENTRER AU VILLAGE", token);
                    lowHpReadings = 0;
                }
                else if (Contains(text, "CONTINUER") && hp.HasValue && hp.Value >= returnThreshold)
                {
                    SetStatus("Victoire : continuer");
                    await ClickTextAsync(bmp, "CONTINUER", token);
                }
                else if (Contains(text, "REPARTIR"))
                {
                    SetStatus("Rapport : repartir");
                    await ClickTextAsync(bmp, "REPARTIR", token);
                }
                else if (Contains(text, "PARTIR"))
                {
                    SetStatus("Préparation : partir");
                    await ClickTextAsync(bmp, "PARTIR", token);
                }
                else
                {
                    SetStatus(hp.HasValue ? $"Analyse : PV {hp.Value:0} %" : "Analyse : PV joueur non lus");
                }

                await Task.Delay(900, token);
            }
            catch (OperationCanceledException) { break; }
            catch (Exception ex)
            {
                SetStatus("Erreur : " + ex.Message);
                try { await Task.Delay(1500, token); } catch (OperationCanceledException) { break; }
            }
        }
    }

    private static bool Contains(string text, string wanted) =>
        text.Replace("’", "'").IndexOf(wanted, StringComparison.OrdinalIgnoreCase) >= 0;

    private static Bitmap CaptureVirtualScreen()
    {
        var bounds = SystemInformation.VirtualScreen;
        var bmp = new Bitmap(bounds.Width, bounds.Height, PixelFormat.Format32bppArgb);
        using var g = Graphics.FromImage(bmp);
        g.CopyFromScreen(bounds.Left, bounds.Top, 0, 0, bounds.Size);
        return bmp;
    }

    private static async Task<double?> DetectHpPercentAsync(Bitmap bmp)
    {
        // First try OCR on the player's card only. Do not require OCR to recognise
        // the tiny "PV" label: some screen scales make that label unreadable.
        try
        {
            using var ms = new System.IO.MemoryStream();
            bmp.Save(ms, ImageFormat.Png);
            ms.Position = 0;

            using var ras = new InMemoryRandomAccessStream();
            await ras.WriteAsync(ms.ToArray().AsBuffer());
            ras.Seek(0);

            var decoder = await BitmapDecoder.CreateAsync(ras);
            var softwareBitmap = await decoder.GetSoftwareBitmapAsync();
            var engine = OcrEngine.TryCreateFromLanguage(new Language("fr-FR"))
                         ?? OcrEngine.TryCreateFromLanguage(new Language("en-US"))
                         ?? OcrEngine.TryCreateFromUserProfileLanguages();

            if (engine is not null)
            {
                var result = await engine.RecognizeAsync(softwareBitmap);
                var fractions = result.Lines
                    .Select(l => new { Rect = GetLineRect(l), Pair = ParseHpPair(l.Text) })
                    .Where(x => x.Pair.HasValue && x.Rect.Width > 0
                             && x.Rect.X < bmp.Width * 0.43
                             && x.Rect.Y > bmp.Height * 0.12
                             && x.Rect.Y < bmp.Height * 0.43)
                    .Select(x => x.Pair!.Value)
                    .Where(p => p.Maximum > 0 && p.Current >= 0 && p.Current <= p.Maximum)
                    .ToList();

                if (fractions.Count > 0)
                {
                    var best = fractions[0];
                    return Math.Clamp(100.0 * best.Current / best.Maximum, 0, 100);
                }
            }
        }
        catch
        {
            // OCR can fail if a language pack is unavailable. Use the visual bar below.
        }

        // Visual fallback: scan only the upper-left player panel, where its green
        // PV bar lives. This deliberately never examines the enemy panel on the right.
        int x0 = Math.Clamp((int)(bmp.Width * 0.07), 0, bmp.Width - 1);
        int x1 = Math.Clamp((int)(bmp.Width * 0.42), x0 + 1, bmp.Width);
        int y0 = Math.Clamp((int)(bmp.Height * 0.15), 0, bmp.Height - 1);
        int y1 = Math.Clamp((int)(bmp.Height * 0.43), y0 + 1, bmp.Height);

        int bestRun = 0;
        int bestY = -1;
        // Sample every second pixel for speed. The actual HP bar is a long,
        // nearly horizontal green run; isolated green icons won't win this test.
        for (int y = y0; y < y1; y += 2)
        {
            int run = 0;
            int rowBest = 0;
            for (int x = x0; x < x1; x += 2)
            {
                var c = bmp.GetPixel(x, y);
                bool green = c.G > 70 && c.G > c.R * 1.30 && c.G > c.B * 1.12;
                if (green)
                {
                    run++;
                    rowBest = Math.Max(rowBest, run);
                }
                else
                {
                    run = 0;
                }
            }
            if (rowBest > bestRun)
            {
                bestRun = rowBest;
                bestY = y;
            }
        }

        // A valid bar should be long and located in the player-card band.
        if (bestY < 0 || bestRun < Math.Max(12, (x1 - x0) / 50))
            return null;

        // Convert sampled pixels back to screen pixels. In this layout the full
        // player PV track is about 14.5% of the screen width.
        double filledWidth = bestRun * 2.0;
        double estimatedTrackWidth = bmp.Width * 0.145;
        return Math.Clamp(100.0 * filledWidth / estimatedTrackWidth, 0, 100);
    }

    private static Windows.Foundation.Rect GetLineRect(OcrLine line)
    {
        var words = line.Words;
        if (words.Count == 0) return new Windows.Foundation.Rect(0, 0, 0, 0);
        double left = words.Min(w => w.BoundingRect.X);
        double top = words.Min(w => w.BoundingRect.Y);
        double right = words.Max(w => w.BoundingRect.X + w.BoundingRect.Width);
        double bottom = words.Max(w => w.BoundingRect.Y + w.BoundingRect.Height);
        return new Windows.Foundation.Rect(left, top, right - left, bottom - top);
    }

    private static (int Current, int Maximum)? ParseHpPair(string text)
    {
        var match = Regex.Match(text, @"(?<cur>\d[\d\s.,]{0,12})\s*/\s*(?<max>\d[\d\s.,]{0,12})");
        if (!match.Success) return null;
        static bool Digits(string value, out int number) =>
            int.TryParse(Regex.Replace(value, @"[^0-9]", ""), out number);
        if (!Digits(match.Groups["cur"].Value, out int current) ||
            !Digits(match.Groups["max"].Value, out int maximum) ||
            maximum <= 0 || current > maximum) return null;
        return (current, maximum);
    }

    private static async Task<string> ReadFrenchTextAsync(Bitmap bmp)
    {
        using var ms = new System.IO.MemoryStream();
        bmp.Save(ms, ImageFormat.Png);
        ms.Position = 0;
        using var ras = new InMemoryRandomAccessStream();
        await ras.WriteAsync(ms.ToArray().AsBuffer());
        ras.Seek(0);
        var decoder = await BitmapDecoder.CreateAsync(ras);
        var sb = await decoder.GetSoftwareBitmapAsync();
        var engine = OcrEngine.TryCreateFromLanguage(new Language("fr-FR")) ?? OcrEngine.TryCreateFromUserProfileLanguages();
        if (engine is null) return "";
        var result = await engine.RecognizeAsync(sb);
        return result.Text ?? "";
    }

    private static async Task<bool> ClickForcePlusAsync(Bitmap bmp, CancellationToken token)
    {
        var result = await RecognizeAsync(bmp);
        foreach (var line in result.Lines)
        {
            if (line.Text.IndexOf("Force", StringComparison.OrdinalIgnoreCase) < 0) continue;
            var rects = line.Words.Select(w => w.BoundingRect).ToArray();
            if (rects.Length == 0) continue;
            int y = (int)((rects.Min(r => r.Y) + rects.Max(r => r.Y + r.Height)) / 2);
            int x = (int)(bmp.Width * 0.68);
            NativeClick.Click(x + SystemInformation.VirtualScreen.Left, y + SystemInformation.VirtualScreen.Top);
            await Task.Delay(300, token);
            return true;
        }
        return false;
    }

    private static async Task ClickTextAsync(Bitmap bmp, string wanted, CancellationToken token)
    {
        var result = await RecognizeAsync(bmp);
        string normalizedWanted = wanted.Replace("!", "").Trim();
        foreach (var line in result.Lines)
        {
            if (line.Text.Replace("!", "").Trim().IndexOf(normalizedWanted, StringComparison.OrdinalIgnoreCase) < 0)
                continue;
            var rects = line.Words.Select(w => w.BoundingRect).ToArray();
            if (rects.Length == 0) continue;
            int x = (int)((rects.Min(r => r.X) + rects.Max(r => r.X + r.Width)) / 2);
            int y = (int)((rects.Min(r => r.Y) + rects.Max(r => r.Y + r.Height)) / 2);
            if (x < 5 || y < 5 || x >= bmp.Width - 5 || y >= bmp.Height - 5) return;
            NativeClick.Click(x + SystemInformation.VirtualScreen.Left, y + SystemInformation.VirtualScreen.Top);
            await Task.Delay(1200, token);
            return;
        }
    }

    private static async Task<OcrResult> RecognizeAsync(Bitmap bmp)
    {
        using var ms = new System.IO.MemoryStream();
        bmp.Save(ms, ImageFormat.Png);
        ms.Position = 0;
        using var ras = new InMemoryRandomAccessStream();
        await ras.WriteAsync(ms.ToArray().AsBuffer());
        ras.Seek(0);
        var decoder = await BitmapDecoder.CreateAsync(ras);
        var sb = await decoder.GetSoftwareBitmapAsync();
        var engine = OcrEngine.TryCreateFromLanguage(new Language("fr-FR")) ?? OcrEngine.TryCreateFromUserProfileLanguages();
        if (engine is null) throw new InvalidOperationException("Le moteur OCR Windows n'est pas disponible.");
        return await engine.RecognizeAsync(sb);
    }
}
