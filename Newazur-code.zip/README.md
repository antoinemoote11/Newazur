# Newazur / AzurBot

Projet Windows C# (.NET 8) avec interface AzurBot et compilation automatique via GitHub Actions.

## Contenu
- `src/AzurBot.csproj` : projet Windows Forms.
- `src/Program.cs` : point d'entrée.
- `src/MainForm.cs` : interface, commandes OCR et détection des PV du joueur.
- `src/NativeClick.cs` : clics Windows.
- `.github/workflows/build.yml` : compilation de l'exécutable Windows.

## Compiler
Chaque push sur `main` lance GitHub Actions. Ouvre l'onglet **Actions**, choisis le workflow `Build AzurBot Windows`, puis télécharge l'artefact `AzurBot-Windows` lorsque le job est vert.

## Notes
La lecture des PV est une estimation basée sur l'OCR et une zone à gauche de l'écran. Elle doit être testée sur la résolution et le zoom réellement utilisés avant un usage sans surveillance. Le bot ne clique sur « Rentrer au village » que si le seuil est franchi sur trois lectures successives et si ce texte est reconnu.
