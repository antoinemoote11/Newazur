AzurBot v12

Cette version conserve le code de la v11 et remplace uniquement NativeClick.cs
par la méthode de clic issue du projet AzurBot_Windows_GitHub_Actions_FINAL10 fourni par l'utilisateur,
qui fonctionne correctement chez lui pour les clics.

Archive à téléverser à la racine du dépôt : Newazur-code-v12.zip
