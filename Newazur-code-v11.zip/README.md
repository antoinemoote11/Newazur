AzurBot v11

Correction ciblée du clic OCR :
- Avant, le bot trouvait une ligne contenant CONTINUER puis cliquait au centre de toute la ligne.
- Maintenant, il calcule le centre de la boîte OCR du mot demandé (ou des mots du libellé demandé), par exemple CONTINUER.
- Les autres fonctionnalités de la v10 sont conservées.

Archive : Newazur-code-v11.zip
