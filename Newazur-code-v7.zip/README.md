# AzurBot v7

Version de diagnostic OCR des PV du joueur. La lecture est limitee a la zone PV de la carte de gauche, avec agrandissement et renforcement du contraste. En cas de lecture incertaine, aucune decision de retour n'est prise.
