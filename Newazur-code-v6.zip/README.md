# AzurBot v6

Version de diagnostic : fenêtre toujours au premier plan et affichage de la dernière paire de PV reconnue par l'OCR. La détection reste limitée à la zone définie pour la carte du joueur à gauche.

Archive à téléverser à la racine du dépôt GitHub sous le nom `Newazur-code-v6.zip`. Le workflow automatique existant sélectionnera la version numérotée la plus élevée.
