AzurBot v10

Corrections :
- Active la conscience DPI Windows afin que les coordonnées de capture écran et de clic soient cohérentes.
- Après les clics sur CONTINUER, REPARTIR et PARTIR, recapture l'écran et vérifie si le bouton est encore visible.
- La lecture des PV reste séparée des clics de progression.

Archive : Newazur-code-v10.zip
