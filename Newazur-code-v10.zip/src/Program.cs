using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace AzurBot;

internal static class Program
{
    [DllImport("user32.dll")]
    private static extern bool SetProcessDPIAware();

    [STAThread]
    private static void Main()
    {
        // Keep screenshot coordinates and mouse coordinates in the same scale.
        SetProcessDPIAware();
        ApplicationConfiguration.Initialize();
        Application.Run(new MainForm());
    }
}
