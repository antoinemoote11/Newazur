AzurBot v9 - lecture des PV depuis le journal de combat

La v9 tente de lire les PV uniquement sur une ligne du journal qui contient le nom exact Shokkryder et une paire actuelle/max sur la même ligne. Les lignes de Céleste et des monstres sont ignorées. Si aucune ligne n'est reconnue, les PV sont considérés comme inconnus et ne déclenchent pas le retour automatique.

Important : l'OCR est testé sur une capture d'écran spécifique; la zone du journal peut nécessiter un ajustement selon la résolution et la disposition du navigateur.
